import java.util.Scanner;

public class ReversePalindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = sc.nextLine();

        String rev = "";

        for(int i = str.length() - 1; i >= 0; i--) {
            rev = rev + str.charAt(i);
        }

        System.out.println("Reversed string: " + rev);

        if(str.equals(rev))
            System.out.println("The string is Palindrome");
        else
            System.out.println("The string is Not Palindrome");

        sc.close();
    }
}
